A Pen created at CodePen.io. You can find this one at http://codepen.io/cmcg/pen/ofFiz.

 Some pretty awful dropdown menu effects done with CSS 